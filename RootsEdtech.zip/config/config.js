module.exports = {
  SECRET_KEY: process.env.JWT_SECRET, // Use .env in production
};